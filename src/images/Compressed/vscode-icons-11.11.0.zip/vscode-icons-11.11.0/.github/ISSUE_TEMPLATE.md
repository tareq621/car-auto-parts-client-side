<!-- markdownlint-disable MD041-->

<!-- Please first read how to submit an issue, if you haven't already done so.
https://github.com/vscode-icons/vscode-icons/wiki/Issue -->

- [ ] I'm sure this issue is not a _duplicate_.
- [ ] I'm submitting an icon request:
  - Type: ``
  - Icon Name: ``
  - Sample original Icon: ![logo]()
  - Extensions: ``
  - Filenames: ``
  - Language ids: ``

- Language Extensions:
- More info:
