export interface IIconPath {
  iconPath: string;
}
