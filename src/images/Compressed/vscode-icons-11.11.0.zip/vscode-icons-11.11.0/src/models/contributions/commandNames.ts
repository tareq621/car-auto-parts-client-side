export enum CommandNames {
  activateIcons,
  regenerateIcons,
  restoreIcons,
  resetProjectDetectionDefaults,
  ngPreset,
  nestPreset,
  jsPreset,
  tsPreset,
  jsonPreset,
  hideFoldersPreset,
  foldersAllDefaultIconPreset,
  hideExplorerArrowsPreset,
}
