import { Projects } from './projects';

export interface IProjectInfo {
  name?: Projects;
  version?: string;
}
