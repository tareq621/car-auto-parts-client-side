export enum Projects {
  angular = 'ng',
  angularjs = 'ngjs',
  nestjs = 'nest',
}
