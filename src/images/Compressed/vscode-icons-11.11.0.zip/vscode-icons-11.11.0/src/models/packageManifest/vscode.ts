import { IVSCodeContributes } from './vscodeContributes';

export interface IVSCodeManifest {
  contributes: IVSCodeContributes;
}
