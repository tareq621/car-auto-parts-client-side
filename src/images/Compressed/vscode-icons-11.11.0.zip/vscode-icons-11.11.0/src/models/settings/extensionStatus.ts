export enum ExtensionStatus {
  activated,
  disabled,
  deactivated,
}
