import { ConfigManager } from './configuration/configManager';

void ConfigManager.removeSettings();
