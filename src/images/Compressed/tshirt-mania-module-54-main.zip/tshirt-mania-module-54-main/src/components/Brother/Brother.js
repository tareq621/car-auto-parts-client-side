import React from 'react';

const Brother = ({house}) => {
    return (
        <div>
            <h5>Brother</h5>
            <p><small>House: {house}</small></p>
        </div>
    );
};

export default Brother;