import React from 'react';

const Uncle = ({house}) => {
    return (
        <div>
            <h4>Uncle</h4>
            <p>House: {house}</p>
        </div>
    );
};

export default Uncle;