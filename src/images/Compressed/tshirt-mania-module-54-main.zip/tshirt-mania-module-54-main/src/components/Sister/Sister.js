import React from 'react';

const Sister = ({house}) => {
    return (
        <div>
            <h5>Sister</h5>
            <p><small>House: {house}</small></p>
        </div>
    );
};

export default Sister;